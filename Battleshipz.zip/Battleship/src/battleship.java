import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.URL;

import javax.swing.*;

public class battleship extends JFrame implements ActionListener, KeyListener {
  public battleship(){
    final JFrame frame = new JFrame("Battleship");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

        JPanel buttonPanel = new JPanel(new GridLayout(10, 10));
        JPanel displayShips = new JPanel(new GridLayout(10, 10));
        JPanel test = new JPanel(new GridLayout(10, 10));
        JPanel cD = new JPanel(new GridLayout(1, 1));
        JPanel cD2 = new JPanel(new GridLayout(1, 1));
        
        JButton buttons[] = new JButton[11];
        JButton eButtons[] = new JButton[101];
        JButton eButtonsTwo[] = new JButton[101];
        
       ActionListener listener2 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JButton button = (JButton) e.getSource();
                if (e.getSource() instanceof JButton) {
                	String text = ("Miss on tile # " + " " + ((JButton) e.getSource()).getText());
                    JOptionPane.showMessageDialog(null, text);
                }
                
                button.setBackground(Color.blue);
                button.setForeground(Color.white);
                button.setOpaque(true);
                button.setEnabled(false);
            }
   };
   
   ActionListener listener3 = new ActionListener() {
       @Override
       public void actionPerformed(ActionEvent e) {
           if (e.getSource() instanceof JButton) {
           	String text = ("Hit on tile # " + " " + ((JButton) e.getSource()).getText());
               JOptionPane.showMessageDialog(null, text);
               
           }
       }
};

ActionListener listener4 = new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        button.setBackground(Color.red);
        button.setForeground(Color.black);
        button.setOpaque(true);
        button.setEnabled(false);
        
        
    }
};

         
//1-25
for(int i = 1; i <=11; i++){
	  eButtons[i] = new JButton(String.valueOf(i));
	  buttonPanel.add(eButtons[i]);
	  eButtons[i].setBackground(Color.BLACK);
	  eButtons[i].setContentAreaFilled(false);
	  eButtons[i].addActionListener(listener2);
	 
  }


for(int i = 12; i <=12; i++){
	  eButtonsTwo[i] = new JButton(String.valueOf(i));
	  buttonPanel.add(eButtonsTwo[i]);
	  //eButtonsTwo[i].setBackground(Color.ORANGE);
	  eButtonsTwo[i].setContentAreaFilled(false);
	  //eButtonsTwo[i].setOpaque(true);
	  eButtonsTwo[i].addActionListener(listener3);
	  eButtonsTwo[i].addActionListener(listener4);
	 
 }

for(int i = 13; i <=25; i++){
	  eButtons[i] = new JButton(String.valueOf(i));
	  buttonPanel.add(eButtons[i]);
	  eButtons[i].setBackground(Color.BLACK);
	  eButtons[i].setContentAreaFilled(false);
	  eButtons[i].addActionListener(listener2);
	 
}


       
		//26-30
       for(int i = 26; i <=28; i++){
    	  eButtonsTwo[i] = new JButton(String.valueOf(i));
    	  buttonPanel.add(eButtonsTwo[i]);
    	  //eButtonsTwo[i].setBackground(Color.ORANGE);
    	  eButtonsTwo[i].setContentAreaFilled(false);
    	  //eButtonsTwo[i].setOpaque(true);
    	  eButtonsTwo[i].addActionListener(listener3);
    	  eButtonsTwo[i].addActionListener(listener4);
    	 
       }
      
    
       //29-70
       for(int i =29; i <=55; i++){
    	  eButtonsTwo[i] = new JButton(String.valueOf(i));
    	  buttonPanel.add(eButtonsTwo[i]);
    	  //eButtonsTwo[i].setBackground(Color.BLACK);
    	  eButtonsTwo[i].setContentAreaFilled(false);
    	  eButtonsTwo[i].addActionListener(listener2);
       }
       
       for(int i = 56; i <=59; i++){
     	  eButtonsTwo[i] = new JButton(String.valueOf(i));
     	  buttonPanel.add(eButtonsTwo[i]);
     	  //eButtonsTwo[i].setBackground(Color.ORANGE);
     	  eButtonsTwo[i].setContentAreaFilled(false);
     	  //eButtonsTwo[i].setOpaque(true);
     	  eButtonsTwo[i].addActionListener(listener3);
     	 eButtonsTwo[i].addActionListener(listener4);
     	 
        }
       
       for(int i =60; i <=70; i++){
     	  eButtonsTwo[i] = new JButton(String.valueOf(i));
     	  buttonPanel.add(eButtonsTwo[i]);
     	  //eButtonsTwo[i].setBackground(Color.BLACK);
     	  eButtonsTwo[i].setContentAreaFilled(false);
     	  eButtonsTwo[i].addActionListener(listener2);
        }
       
       //71 - 90
       for(int i =71; i <=90; i++){
     	  eButtonsTwo[i] = new JButton(String.valueOf(i));
     	  buttonPanel.add(eButtonsTwo[i]);
     	  //eButtonsTwo[i].setBackground(Color.BLACK);
     	  eButtonsTwo[i].setContentAreaFilled(false);
     	  eButtonsTwo[i].addActionListener(listener2);
        }
       
     //91 - 95, CARRIER
       for(int i =91; i <=95; i++){
     	  eButtonsTwo[i] = new JButton(String.valueOf(i));
     	  buttonPanel.add(eButtonsTwo[i]);
     	  //eButtonsTwo[i].setBackground(Color.ORANGE);
     	  eButtonsTwo[i].setContentAreaFilled(false);
     	  //eButtonsTwo[i].setOpaque(true);
     	  eButtonsTwo[i].addActionListener(listener3);
     	 eButtonsTwo[i].addActionListener(listener4);
        }
     //96 - 97
       for(int i =96; i <=98; i++){
     	  eButtonsTwo[i] = new JButton(String.valueOf(i));
     	  buttonPanel.add(eButtonsTwo[i]);
     	  eButtonsTwo[i].setContentAreaFilled(false);
     	  eButtonsTwo[i].addActionListener(listener2);
        }
       //91 - 95, DESTROYER
       for(int i =99; i <=100; i++){
     	  eButtonsTwo[i] = new JButton(String.valueOf(i));
     	  buttonPanel.add(eButtonsTwo[i]);
     	  //eButtonsTwo[i].setBackground(Color.ORANGE);
     	  eButtonsTwo[i].setContentAreaFilled(false);
     	  //eButtonsTwo[i].setOpaque(true);
     	  eButtonsTwo[i].addActionListener(listener3);
     	 eButtonsTwo[i].addActionListener(listener4);
        }
       
     //WEST panel information
       
     //1-25
       for(int i = 1; i <=11; i++){
       	  eButtons[i] = new JButton(String.valueOf(i));
       	  displayShips.add(eButtons[i]);
       	  eButtons[i].setBackground(Color.BLACK);
       	  eButtons[i].setContentAreaFilled(false);
       	  eButtons[i].addActionListener(listener2);
       	 
         }


       for(int i = 12; i <=12; i++){
       	  eButtonsTwo[i] = new JButton(String.valueOf(i));
       	  displayShips.add(eButtonsTwo[i]);
       	  eButtonsTwo[i].setBackground(Color.ORANGE);
       	  eButtonsTwo[i].setContentAreaFilled(false);
       	  eButtonsTwo[i].setOpaque(true);
       	  eButtonsTwo[i].addActionListener(listener3);
       	  eButtonsTwo[i].addActionListener(listener4);
       	 
        }

       for(int i = 13; i <=25; i++){
       	  eButtons[i] = new JButton(String.valueOf(i));
       	  displayShips.add(eButtons[i]);
       	  eButtons[i].setBackground(Color.BLACK);
       	  eButtons[i].setContentAreaFilled(false);
       	  eButtons[i].addActionListener(listener2);
       	 
       }


              
       		//26-30
              for(int i = 26; i <=28; i++){
           	  eButtonsTwo[i] = new JButton(String.valueOf(i));
           	  displayShips.add(eButtonsTwo[i]);
           	  eButtonsTwo[i].setBackground(Color.ORANGE);
           	  eButtonsTwo[i].setContentAreaFilled(false);
           	  eButtonsTwo[i].setOpaque(true);
           	  eButtonsTwo[i].addActionListener(listener3);
           	  eButtonsTwo[i].addActionListener(listener4);
           	 
              }
             
           
              //29-70
              for(int i =29; i <=55; i++){
           	  eButtonsTwo[i] = new JButton(String.valueOf(i));
           	  displayShips.add(eButtonsTwo[i]);
           	  //eButtonsTwo[i].setBackground(Color.BLACK);
           	  eButtonsTwo[i].setContentAreaFilled(false);
           	  eButtonsTwo[i].addActionListener(listener2);
              }
              
              for(int i = 56; i <=59; i++){
            	  eButtonsTwo[i] = new JButton(String.valueOf(i));
            	  displayShips.add(eButtonsTwo[i]);
            	  eButtonsTwo[i].setBackground(Color.ORANGE);
            	  eButtonsTwo[i].setContentAreaFilled(false);
            	  eButtonsTwo[i].setOpaque(true);
            	  eButtonsTwo[i].addActionListener(listener3);
            	 eButtonsTwo[i].addActionListener(listener4);
            	 
               }
              
              for(int i =60; i <=70; i++){
            	  eButtonsTwo[i] = new JButton(String.valueOf(i));
            	  displayShips.add(eButtonsTwo[i]);
            	  //eButtonsTwo[i].setBackground(Color.BLACK);
            	  eButtonsTwo[i].setContentAreaFilled(false);
            	  eButtonsTwo[i].addActionListener(listener2);
               }
              
              //71 - 90
              for(int i =71; i <=90; i++){
            	  eButtonsTwo[i] = new JButton(String.valueOf(i));
            	  displayShips.add(eButtonsTwo[i]);
            	  //eButtonsTwo[i].setBackground(Color.BLACK);
            	  eButtonsTwo[i].setContentAreaFilled(false);
            	  eButtonsTwo[i].addActionListener(listener2);
               }
              
            //91 - 95, CARRIER
              for(int i =91; i <=95; i++){
            	  eButtonsTwo[i] = new JButton(String.valueOf(i));
            	  displayShips.add(eButtonsTwo[i]);
            	  eButtonsTwo[i].setBackground(Color.ORANGE);
            	  eButtonsTwo[i].setContentAreaFilled(false);
            	  eButtonsTwo[i].setOpaque(true);
            	  eButtonsTwo[i].addActionListener(listener3);
            	 eButtonsTwo[i].addActionListener(listener4);
               }
            //96 - 97
              for(int i =96; i <=98; i++){
            	  eButtonsTwo[i] = new JButton(String.valueOf(i));
            	  displayShips.add(eButtonsTwo[i]);
            	  eButtonsTwo[i].setContentAreaFilled(false);
            	  eButtonsTwo[i].addActionListener(listener2);
               }
              //91 - 95, DESTROYER
              for(int i =99; i <=100; i++){
            	  eButtonsTwo[i] = new JButton(String.valueOf(i));
            	  displayShips.add(eButtonsTwo[i]);
            	  eButtonsTwo[i].setBackground(Color.ORANGE);
            	  eButtonsTwo[i].setContentAreaFilled(false);
            	  eButtonsTwo[i].setOpaque(true);
            	  eButtonsTwo[i].addActionListener(listener3);
            	 eButtonsTwo[i].addActionListener(listener4);
               }
              

		/*		JButton dbg = new JButton("Hide");
				 dbg.setBackground(Color.CYAN);
				 dbg.setContentAreaFilled(false);
				 dbg.setOpaque(true);
				 cD.add(dbg);
				 dbg.addActionListener(new ActionListener() {
			        public void actionPerformed(ActionEvent e){
			            displayShips.setVisible(false);
			          }
			     });      
			*/	 
		/*		 JButton dbg2 = new JButton("Enable");
				 dbg2.setBackground(Color.GREEN);
				 dbg2.setContentAreaFilled(false);
				 dbg2.setOpaque(true);
					cD.add(dbg2);
					 dbg2.addActionListener(new ActionListener() {
				        public void actionPerformed(ActionEvent e){
				            displayShips.setVisible(true);
				          }
				     });    
					 
					 JButton dbg3 = new JButton("Close");
					 dbg3.setBackground(Color.RED);
					 dbg3.setContentAreaFilled(false);
					 dbg3.setOpaque(true);
						cD.add(dbg3);
						 dbg3.addActionListener(new ActionListener() {
					        public void actionPerformed(ActionEvent e){
					            frame.dispose();		          }
					     });
				*/		 
						 JButton dbg4 = new JButton("Information");
						 dbg4.setBackground(Color.YELLOW);
						 dbg4.setContentAreaFilled(false);
						 dbg4.setOpaque(true);
							cD.add(dbg4);
							 dbg4.addActionListener(new ActionListener() {
						        public void actionPerformed(ActionEvent e){
						        	String text = ("There is 1 Aircraft[5], 1 Battleship[4], 1 Cruiser[3], 1 Destroyer[2], 1 Sub[1]");
						               JOptionPane.showMessageDialog(null, text);       
						               }
						     });		


		JPanel center = new JPanel(){
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(170, 170);
            }
        };
        		   
        center.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        frame.add(center);
   
        displayShips.setVisible(false);
    
      	JPanel east = new JPanel(new GridBagLayout());
      	JPanel south = new JPanel(new GridBagLayout());
    	JPanel south2 = new JPanel(new GridBagLayout());
    	
    	URL url = battleship.class.getResource("/resources/logo.gif");
    	ImageIcon imageIcon = new ImageIcon(url);
    	Image scaled = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_FAST);
    	
    	JLabel version = new JLabel("Version 1.0.1");
    	
    	
    	JLabel background = new JLabel(imageIcon);
    	
      	
    
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weighty = 1;
        
    
        east.add(buttonPanel, gbc); 
        //east.add(background);
        south.add(displayShips, gbc);
        south2.add(test, gbc);
        center.add(cD, gbc);
        center.add(background);
        center.add(version);
     	frame.add(east, BorderLayout.EAST);
     	frame.add(south, BorderLayout.WEST);	
     	frame.add(south2, BorderLayout.SOUTH);
     	

     	frame.pack();
        frame.setVisible(true);
    
  }
  
  public static void main(String[] args){
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {
      	e.printStackTrace();
    }
    SwingUtilities.invokeLater(new Runnable() {
      @Override
      public void run(){
        new battleship();
      }
    });
    
  	}

@Override
public void keyPressed(KeyEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void keyReleased(KeyEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void keyTyped(KeyEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}

}
  